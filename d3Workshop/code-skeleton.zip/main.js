var _data;

/**
 * Do the following when the browser window loads
 */
window.onload = function(){
    // console.log("Hello World!");
    // loadData("betterlifeindex.csv");
};

function loadData(path){
    d3.csv(path).then(function(data){
        console.log(data);
        _data = data;

        // drawCountries(_data);
        // drawBars(_data);
    });
}

function drawCountries(data){
    let svg = d3.select("#vis2");

    // viewbox: "origin, ratio"
    let ratioWidth = $("#vis2").width();
    let ratioHeight = $("#vis2").height();
    svg.attr("viewBox", "0,0," + ratioWidth + "," + ratioHeight);

    svg.selectAll("rect")
        .data(data)
        .enter()
        .append("rect")
        .attr("x", function(d,i){
            return (i+1) * 15;
        })
        .attr("y", 10)
        .attr("width", 10)
        .attr("height", 200);
}

function drawBars(data){
    let svg = d3.select("#vis3");

    // viewbox: "origin, ratio"
    let ratioWidth = $("#vis3").width();
    let ratioHeight = $("#vis3").height();
    svg.attr("viewBox", "0,0," + ratioWidth + "," + ratioHeight);

    let width = $("#vis3").width();
    let height = $("#vis3").height();
    let barWidth = width/data.length;

    //setup D3 scales
    let xScale = d3.scaleLinear()
        .domain([0,data.length])
        .range([0,width]);

    let yScale = d3.scaleLinear()
        .domain([0, d3.max(data, function(d){
            return d['Water quality'];
        })])
        .range([height,0]);

    svg.selectAll("rect")
        .data(data)
        .enter()
        .append("rect")
        .attr("x", function(d,i){
            return xScale(i);
        })
        .attr("y", function(d,i){
            return yScale(d['Water quality']);
        })
        .attr("width", barWidth)
        .attr("height", height)
        .style("stroke", "rgb(0,191,255)")
        .style("stroke-width", 5);
}