/**
 * Constructor function for a Visualization that displays data as "flowers"
 * @param data (not required) the data array to visualize
 * @constructor
 */
var FlowerVis = function(data){
    this.data = data;
    this.width;
    this.height;
    this.svgContainer;

    this.FLOWER_WIDTH = 150;    // width for each flower in the visualization
    this.FLOWER_HEIGHT = 200;   // height for each flower in the visualization
    this.flowers; // groups of svg containing svg shapes that form a "flower"

    /**
     * Function that creates all of the small multiple flowers in the visualization
     */
    this.createFlowers = function(){
        let _this = this;               // save the context of the visualization object
        let max_num_of_items = 8;      // max number of items on the x-axis

    };

    /**
     * Function that adds a petal to a flower group. The petal's length is based off a data, accessed through a given
     * property selector
     * @param rotation_angle (number, degree) the angle of rotation for the petal
     * @param selector (string) the property of the data which will determine
     * @param max_val (number) the maximum value the data domain has (used for scaling values to screen pixels)
     * @param fill (colour string) the colour of the petal
     * @param stroke (colour string) the colour of the stroke outlining the petal on hover
     */
    this.addPetal = function(rotation_angle, selector, max_val, fill, stroke){
        let _this = this;   // save the context of the visualization
        // create a group that will contain the SVG:path for our petal
        let petal_group = this.flowers.append("g")
            .attr("transform", `rotate(${rotation_angle}, ${_this.FLOWER_WIDTH/2}, ${_this.FLOWER_HEIGHT/2})`);

        // Add a path into the group using a Quadratic Bezier curve definition
        // recall the quadratic curve definition: Mx y, Q cx cy, dx dy
        // where x and y are the coords of the point of origin, cx and cy is the control point,
        // and dx dy is the next point (this can be followed up by another control point and next point ...
        let petal = petal_group.append("path")
            .attr("class", "flower_petal")
            .attr("selector", selector)
            .attr("d", function(d){
                let origin = {x : _this.FLOWER_WIDTH/2, y : _this.FLOWER_HEIGHT/2};
                let scale = d3.scaleLinear()
                    .domain([0, max_val])
                    .range([0, _this.FLOWER_HEIGHT/2]);
                let top = {x : origin.x, y : origin.y - scale(d[selector])};
                let ctrl1 = {x : origin.x - (origin.x/4), y: top.y + ((_this.FLOWER_HEIGHT/2-top.y)/2)};
                let ctrl2 = {x : origin.x + (origin.x/4), y: top.y + ((_this.FLOWER_HEIGHT/2-top.y)/2)};
                let path = `M${origin.x} ${origin.y} Q ${ctrl1.x} ${ctrl1.y}, ${top.x} ${top.y} 
                        Q ${ctrl2.x} ${ctrl2.y}, ${origin.x} ${origin.y} Z`;
                return path;
            })
            .style("opacity", 0)
            .style("fill", fill);

        petal
            .transition()
            .style("opacity", 1)
            .duration(800);

        petal
            .append("svg:title")
            .text(function(d){
                return `${selector}: ${d[selector]}`;
            });
    }
};